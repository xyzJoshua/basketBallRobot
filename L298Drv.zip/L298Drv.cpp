#include "L298Drv.h"

// 초기화 함수
//   pwmPin: PWM 출력이 가능한 핀 번호
//   doPin: Digital Output으로 사용할 핀
//   reverse: true면 drive 함수의 회전 방향을 반대로 함, default는 false
L298Drv::L298Drv(uint8_t pwmPin, uint8_t doPin, boolean reverse)
{
  _pwmPin = pwmPin;
  _doPin = doPin;
	_reverse = reverse;
 
  pinMode(_doPin, OUTPUT);
}

// 모터 구동 함수
//   pwm: 절대값은 0~255의 PWM duty cycle, 부호는 회전 방향
// 참고: L298Drv의 초기화 함수에서 reverse를 true로 하면 회전방향이 반대로 됨
void L298Drv::drive(int pwm)
{
  // -255~255로 clipping
  if (pwm < -255) {
    pwm = -255;
  }
  if (pwm > 255) {
    pwm = 255;
  }

  // reverse면 방향을 반대로
  if (_reverse) {
    pwm = -pwm;
  }

  // PWM 출력으로 모터 구동
  if (pwm >= 0) {
    digitalWrite(_doPin, LOW);
    analogWrite(_pwmPin, pwm);
  }
  else {
    digitalWrite(_doPin, HIGH);
    analogWrite(_pwmPin, 255 + pwm);
  }
}
