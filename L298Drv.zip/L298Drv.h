#ifndef _L298DRV_H_INCLUDE
#define _L298DRV_H_INCLUDE

#include "Arduino.h"

class L298Drv {
private:
  uint8_t _pwmPin;
  uint8_t _doPin;
  uint8_t _reverse;

public:
  L298Drv(uint8_t pwmPin, uint8_t doPin, boolean reverse = false);
  void drive(int pwm);
};

#endif
